<?php
$con = mysqli_connect("localhost", "root", "", "star_advertising") or die("Connection Error");

if (isset($_REQUEST['sbmt'])) {
    $name = $_POST['name'];
    $company = $_POST['companyName'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $requirement = $_POST['requirement'];


    if ($name != "" && $company != "" && $mobile != "" && $email != "" && $requirement != "") {


        $insertQuery = "INSERT INTO `inquiry`( `name`, `company`, `mobile`, `email`, `requirement`) VALUES ('$name','$company','$mobile','$email','$requirement')";

        $numRow = mysqli_query($con, $insertQuery);
        if ($numRow > 0) {

            $from = "inquirystaradvertising@gmail.com";
            $toemail = $email;
            $subject = "Inquiry";
            $message = $requirement;

            $result = mail($toemail, $subject, $message, "From: $from");
            if ($result) {
                ?>
                <script>
                    alert("inquiry Submitted");
                    window.location.href = "contact.html";
                </script>
    <?php
                } else {
                    echo 'FAIL';
                }
            }
        } else{

            ?>
    <script>
        alert("Please Fill the details");
    </script>
<?php
        }
}
?>